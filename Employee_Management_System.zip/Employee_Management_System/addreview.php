<?php 

$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "ems";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$conn){
	echo "Databese Connection Failed";
}



if (isset($_POST['userreview']))	{

	//include "dbh.php";

	// $category = $_POST['category'];
  $ref_id = $_POST['refid'];
  $category = $_POST['cat'];
  $details = $_POST['det'];
  $userid = $_POST['userid'];
	$userreview = $_POST['userreview'];
	
  echo $ref_id;
	echo $category; 
	echo $details; 
  echo $userid;
  echo $userreview;

	// if (empty($category)) {
	// 	header("Location: addoffermedical.html?ms=Name is required");
	//     exit;
		
	// }
	// else 
  // if(empty($userreview)) {
	// 	header("Location: createreview.php?ms=review is required");
	//     exit;
	// }
	// else 
  {
		
        $sql = "INSERT INTO reviews(ref_id, category, details, user_id, review)VALUES('$ref_id', '$category', '$details', '$userid', '$userreview')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
        	$ms = "Successfully created";
        	header("Location: notify.php?ms=$ms");
	        exit;
        }else {
        	$ms = "Unknown error occurred";
        	header("Location: notify.php?ms=$ms");
	        exit;
        }

	}
}else {
	header("Location: ../signup.php");
	exit;
}
