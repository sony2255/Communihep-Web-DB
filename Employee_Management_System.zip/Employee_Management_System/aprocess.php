<?php

require_once('dbh.php');
session_start(); // Start a session

$email = $_POST['email'];
$pass = $_POST['pass'];

$sql = "SELECT * FROM `sign_up` WHERE email = '$email' AND pass = '$pass'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    // User is successfully logged in
    while($row = mysqli_fetch_assoc($result)){ // Fetch the user's data
    $user_id = $row['user_id'];// Extract user_id from the result
    $user_name = $row['username'];
    echo $user_id;
    echo $user_name;
    
    // Store user_id in a session variable
    $_SESSION['user_id'] = $user_id;
    $_SESSION['user_name'] = $user_name;
    
    echo $_SESSION['user_name'];

        header("Location: home.php");
} }else {
    echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

?>
