<?php 



$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "ems";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$conn){
	echo "Databese Connection Failed";
}
$name = $_POST['name'];
if (isset($_POST['category']) ||
	isset($_POST['details']))	{

	//include "dbh.php";

	$category = $_POST['category'];
	$details = $_POST['details'];
	
	echo $category; 
	echo $details; 

	if (empty($category)) {
		header("Location: addofferservices.html?ms=Name is required");
	    exit;
		
	}
	else if(empty($details)) {
		header("Location: addofferservices.html?ms=Password is required");
	    exit;
	}
	else {
		
        $sql = "INSERT INTO offer_request(user_id, offerrequest, type, category,details)VALUES($name, 'offer','services','$category','$details')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
        	$ms = "Successfully created";
        	header("Location: myhistory.php?ms=$ms");
	        exit;
        }else {
        	$ms = "Unknown error occurred";
        	header("Location: addofferservices.html?ms=$ms");
	        exit;
        }

	}
}else {
	header("Location: ../signup.php");
	exit;
}
