<?php 

session_start();
$name = $_SESSION['user_id'];


$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "ems";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$conn){
	echo "Databese Connection Failed";
}


if (isset($_POST['username']) ||
	isset($_POST['phonenumber'])||
	isset($_POST['email'])
 ){

	//include "dbh.php";

	$username = $_POST['username'];
	$phone_number = $_POST['phonenumber'];
	$email = $_POST['email'];
	echo $name;
	echo $username; 
	echo $email; 
	echo $phone_number;

	if (empty($username)) {
		header("Location: signup.php?ms=Name is required");
	    exit;
	}
	else if(empty($phone_number)) {
		header("Location: signup.php?ms=Password is required");
	    exit;
	}else if(empty($email)) {
		header("Location: signup.php?ms=Mobile Number is required");
	    exit;
	}
	else {
		
        //$sql = "INSERT INTO sign_up(username,email,phone_number )VALUES('$username','$email','$phone_number')";
        $sql = "UPDATE `sign_up` SET `username`='$username',`email`='$email',`phone_number`=$phone_number WHERE `user_id`=$name";
        $result = mysqli_query($conn, $sql);

        if ($result) {
        	$ms = "Edited Profile Successfully";
        	header("Location: profile.php?ms=$ms");
	        exit;
        }else {
        	$ms = "Unknown error occurred";
        	header("Location: profile.php?ms=$ms");
	        exit;
        }

	}
}else {
	header("Location: profile.php");
	exit;
}
