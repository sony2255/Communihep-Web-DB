<!DOCTYPE html>
<?php
session_start();
$name = $_SESSION['user_id'];

?>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style.css" />
    <style>
      .desktop {
  background-color: #ffffff;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;
}

.desktop .div {
  background-color: #ffffff;
  width: 1440px;
  height: 1024px;
  position: relative;
}

.desktop .text-wrapper {
  position: absolute;
  width: 285px;
  top: 195px;
  left: 578px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #244065;
  font-size: 30px;
  letter-spacing: 0;
  line-height: normal;
  white-space: nowrap;
}

.desktop .overlap-group {
  position: absolute;
  width: 260px;
  height: 30px;
  top: 300px;
  left: 581px;
  background-color: #ebebeb;
  border-radius: 0px;
 
}

.desktop .text-wrapper-2 {
  position: absolute;
  width: 94px;
  top: 200px;
  left: 581px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
 
  border: none;
}

.desktop .overlap {
  position: absolute;
  width: 278px;
  height: 30px;
  top: 450px;
  left: 581px;
  background-color: #ebebeb;
  border-radius: 10px;
  
}

.desktop .confirm-password {
  position: absolute;
  width: 235px;
  top: 450px;
  left: 581px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
  border: none;
}

.desktop .password-wrapper {
  position: absolute;
  width: 278px;
  height: 30px;
  top: 422px;
  left: 581px;
  background-color: #ebebeb;
  border-radius: 10px;
  
}

.desktop .password {
  position: absolute;
  width: 152px;
  top: 402px;
  left: 581px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
  border: none;
}

.desktop .email-wrapper {
  position: absolute;
  width: 278px;
  height: 40px;
  top: 350px;
  left: 581px;
  background-color: #ebebeb;
  border-radius: 0px;
  
}

.desktop .email {
  position: absolute;
  width: 66px;
  top: 350px;
  left: 581px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
  border: #ffffff;
}

.desktop .phone-no-wrapper {
  position: absolute;
  width: 278px;
  height: 30px;
  top: 250px;
  left: 581px;
  background-color: #ebebeb;
  border-radius: 0px;
  
  border: none;
}

.desktop .phone-no {
  position: absolute;
  width: 163px;
  top: 275px;
  left: 581px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
}

.desktop .overlap-2 {
  position: absolute;
  width: 195px;
  height: 36px;
  top: 512px;
  left: 623px;
}

.desktop .rectangle {
  position: absolute;
  width: 316px;
  height: 206px;
  top: 10px;
  left: 557px;
  object-fit: cover;
}

.desktop .text-wrapper-6 {
  position: absolute;
  width: 58px;
  top: 3px;
  left: 68px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #ffffff;
  font-size: 14px;
  letter-spacing: 0;
  line-height: normal;
}

.desktop .text-wrapper-3 {
  position: absolute;
  width: 133px;
  top: 7px;
  left: 95px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #ffffff;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
  white-space: nowrap;
}

.desktop .div-wrapper {
  width: 235px;
  height: 30px;
  top: 450px;
  left: 602px;
  background-color: #ffffff;
  position: absolute;
  border-radius: 10px;
}

    </style>
  </head>
  <body>
    
    <div class="desktop">
      <!-- <div class="div">
        <img class="rectangle" src="images\logo.jpg" />
        <div class="text-wrapper">Join the Community</div> -->
        <form action="editpro.php" method="post">
        <mark>
            <?php if (isset($_GET['ms']))
            {
              echo $_GET['ms'];
            }
            ?>
          </mark>
        <input style="width:300px; margin-left:0%; height:40px;"    
            class="overlap-group text-wrapper-2" placeholder=" Name" name="username" type="text">
        <input style="width:300px; margin-left:0%; height:40px;"    
            class="phone-no-wrapper phone-no" name="phonenumber" placeholder=" Phone Number" type="text">
        <input style="width: 300px;; margin-left: 0%; heigt:40px;"    
            class="email-wrapper email" placeholder=" Email" name="email" type="text">
        <input class="div-wrapper" type="submit" value="EDIT PROFILE" name="signup" style="color:#000000"><div class="text-wrapper-3">EDIT PROFILE</div>
        <!-- <input type="hidden" name="name" value="<?php echo isset($_SESSION["user_id"]) ? $_SESSION["user_id"]:'';?>"> -->
      </form>
      </div>
    </div>
  </body>
</html>
