<?php

require_once ('dbh.php');

$email = $_POST['email'];
$pass = $_POST['pass'];

echo $email;
$sql = "SELECT * from `sign_up` WHERE email = '$email' AND pass = '$pass'";

//echo "$sql";

$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) == 1){
	

	echo ("logged in");
	header("Location: home.php?ms=$ms");
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}
?>