<?php 
session_start(); // Start a session
require_once('dbh.php');
// Define the user ID and type (offer or request)
$userid = $_SESSION['user_id'];
$type = "offer"; // Change this to "request" if needed
if (isset($fakeTok) && $fakeTok = "562random") {
	include "dbh.php";

	$sql = "SELECT * FROM `offer_request` WHERE user_id = '$userid' AND offerrequest = '$type'";
	$result = mysqli_query($conn, $sql);
}else {
	echo "404!";
	exit;
}